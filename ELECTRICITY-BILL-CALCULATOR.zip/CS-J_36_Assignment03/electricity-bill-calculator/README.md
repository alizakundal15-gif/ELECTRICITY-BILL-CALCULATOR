# CS-J 36 – Assignment 03: Electricity Bill Calculator (Java Servlet)

A responsive web app that calculates an electricity bill using a Java Servlet.

## Tariff

| Units                 | Rate (Rs/unit) |
|-----------------------|----------------|
| First 50 (1–50)       | 3.50           |
| Next 100 (51–150)     | 4.00           |
| Next 100 (151–250)    | 5.20           |
| Above 250             | 6.50           |

Example: 320 units = 50×3.50 + 100×4.00 + 100×5.20 + 70×6.50 = **Rs. 1550.00**

## Project structure

```
electricity-bill-calculator/
├── pom.xml
└── src/main/
    ├── java/com/csj36/electricity/
    │   ├── BillCalculator.java          # slab-wise calculation logic
    │   └── ElectricityBillServlet.java  # @WebServlet("/calculate"), generates the bill page
    └── webapp/
        ├── index.html                   # input form + tariff table
        ├── css/style.css                # responsive styles
        └── WEB-INF/web.xml
```

## Requirements

- JDK 17+
- Apache Maven
- Apache Tomcat 10 or later (uses the `jakarta.servlet` API)

## Build and run

```
mvn clean package
```

Copy `target/electricity-bill.war` into Tomcat's `webapps/` folder, start Tomcat, then open:

http://localhost:8080/electricity-bill/

In Eclipse/IntelliJ you can instead import it as a Maven project and run it on a Tomcat 10 server.
