package com.csj36.electricity;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

/**
 * Reads the form submitted from index.html, calculates the slab-wise
 * electricity bill and responds with a responsive HTML bill.
 */
@WebServlet("/calculate")
public class ElectricityBillServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        // The form lives on index.html; a direct GET just goes back there.
        resp.sendRedirect(req.getContextPath() + "/index.html");
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        req.setCharacterEncoding("UTF-8");
        resp.setContentType("text/html;charset=UTF-8");

        String name = trim(req.getParameter("name"));
        String consumerNo = trim(req.getParameter("consumerNo"));
        String unitsText = trim(req.getParameter("units"));

        PrintWriter out = resp.getWriter();
        pageStart(out);

        String error = validate(name, consumerNo, unitsText);
        if (error != null) {
            out.println("<div class='card'>");
            out.println("<h2 class='error-title'>Invalid input</h2>");
            out.println("<p class='error'>" + escape(error) + "</p>");
            out.println("<a class='btn' href='index.html'>&larr; Go back</a>");
            out.println("</div>");
            pageEnd(out);
            return;
        }

        double units = Double.parseDouble(unitsText);
        List<BillCalculator.SlabCharge> rows = BillCalculator.breakdown(units);
        double total = BillCalculator.total(rows);

        out.println("<div class='card'>");
        out.println("<h2>Electricity Bill</h2>");

        out.println("<div class='details'>");
        detail(out, "Consumer Name", escape(name));
        detail(out, "Consumer No.", escape(consumerNo));
        detail(out, "Bill Date", LocalDate.now().format(DateTimeFormatter.ofPattern("dd MMM yyyy")));
        detail(out, "Units Consumed", fmtUnits(units));
        out.println("</div>");

        out.println("<div class='table-wrap'><table>");
        out.println("<thead><tr><th>Slab</th><th>Rate (Rs/unit)</th><th>Units</th><th>Amount (Rs)</th></tr></thead>");
        out.println("<tbody>");
        for (BillCalculator.SlabCharge row : rows) {
            String cls = row.units > 0 ? "" : " class='unused'";
            out.println("<tr" + cls + ">"
                    + "<td data-label='Slab'>" + row.label + "</td>"
                    + "<td data-label='Rate'>" + String.format("%.2f", row.rate) + "</td>"
                    + "<td data-label='Units'>" + fmtUnits(row.units) + "</td>"
                    + "<td data-label='Amount'>" + String.format("%.2f", row.amount) + "</td>"
                    + "</tr>");
        }
        out.println("</tbody>");
        out.println("</table></div>");

        out.println("<div class='total'><span>Total Amount Payable</span>"
                + "<strong>Rs. " + String.format("%,.2f", total) + "</strong></div>");

        out.println("<div class='actions'>");
        out.println("<a class='btn' href='index.html'>Calculate Another</a>");
        out.println("<button class='btn btn-outline' onclick='window.print()'>Print Bill</button>");
        out.println("</div>");
        out.println("</div>");

        pageEnd(out);
    }

    private static String validate(String name, String consumerNo, String unitsText) {
        if (name.isEmpty()) return "Please enter the consumer name.";
        if (consumerNo.isEmpty()) return "Please enter the consumer number.";
        if (unitsText.isEmpty()) return "Please enter the units consumed.";
        try {
            double units = Double.parseDouble(unitsText);
            if (Double.isNaN(units) || Double.isInfinite(units) || units < 0) {
                return "Units consumed must be a non-negative number.";
            }
        } catch (NumberFormatException e) {
            return "Units consumed must be a valid number.";
        }
        return null;
    }

    private static void pageStart(PrintWriter out) {
        out.println("<!DOCTYPE html>");
        out.println("<html lang='en'><head>");
        out.println("<meta charset='UTF-8'>");
        out.println("<meta name='viewport' content='width=device-width, initial-scale=1.0'>");
        out.println("<title>Electricity Bill</title>");
        out.println("<link rel='stylesheet' href='css/style.css'>");
        out.println("</head><body>");
        out.println("<header class='site-header'><h1>&#9889; Electricity Bill Calculator</h1></header>");
        out.println("<main class='container'>");
    }

    private static void pageEnd(PrintWriter out) {
        out.println("</main>");
        out.println("<footer class='site-footer'>CS-J 36 &middot; Assignment 03 &middot; Java Servlet</footer>");
        out.println("</body></html>");
    }

    private static void detail(PrintWriter out, String label, String value) {
        out.println("<div class='detail'><span>" + label + "</span><strong>" + value + "</strong></div>");
    }

    private static String fmtUnits(double units) {
        return units == Math.floor(units) ? String.format("%.0f", units) : String.format("%.2f", units);
    }

    private static String trim(String s) {
        return s == null ? "" : s.trim();
    }

    private static String escape(String s) {
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
                .replace("\"", "&quot;").replace("'", "&#39;");
    }
}
