package com.csj36.electricity;

import java.util.ArrayList;
import java.util.List;

/**
 * Slab-wise electricity bill calculation.
 *
 *   First 50 units        : Rs. 3.50 / unit
 *   Next 100 units (51-150): Rs. 4.00 / unit
 *   Next 100 units (151-250): Rs. 5.20 / unit
 *   Above 250 units       : Rs. 6.50 / unit
 */
public class BillCalculator {

    /** One row of the bill breakdown. */
    public static class SlabCharge {
        public final String label;
        public final double rate;
        public final double units;
        public final double amount;

        SlabCharge(String label, double rate, double units) {
            this.label = label;
            this.rate = rate;
            this.units = units;
            this.amount = units * rate;
        }
    }

    // Slab size (units) and rate (Rs/unit); the last slab has no upper limit.
    private static final String[] LABELS = {"First 50 units (1 - 50)", "Next 100 units (51 - 150)",
            "Next 100 units (151 - 250)", "Above 250 units"};
    private static final double[] SIZES = {50, 100, 100, Double.MAX_VALUE};
    private static final double[] RATES = {3.50, 4.00, 5.20, 6.50};

    public static List<SlabCharge> breakdown(double units) {
        List<SlabCharge> rows = new ArrayList<>();
        double remaining = units;
        for (int i = 0; i < RATES.length; i++) {
            double inSlab = Math.max(0, Math.min(remaining, SIZES[i]));
            rows.add(new SlabCharge(LABELS[i], RATES[i], inSlab));
            remaining -= inSlab;
        }
        return rows;
    }

    public static double total(List<SlabCharge> rows) {
        double sum = 0;
        for (SlabCharge row : rows) {
            sum += row.amount;
        }
        return sum;
    }
}
